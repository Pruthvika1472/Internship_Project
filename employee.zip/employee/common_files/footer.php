
<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>  <!-- JQuery cdn -->
<script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>  <!-- search bar and pageno things -->
<script>
  $(document).ready(function () {
    $(".table").DataTable();
  });
</script>
</body>
</html>