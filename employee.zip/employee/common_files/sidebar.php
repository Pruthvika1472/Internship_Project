<nav>
<a href="#"><img src="assets/img/headlogo.jpg" alt="Logo" class="sidelogo"></a><hr>
<ul>
    <li><a href="index.php"><img src="assets/img/home-icon.svg">  Home</a></li>
    <li><a href="regis.php"><img src="assets/img/adduser-icon.svg" style="width:25px;height:25px;">Registration</a></li>
   <!-- <li><a href="regisemp.php">Registered Employee</a></li>  -->
    <li><a href="empmanagement.php"><img src="assets/img/empmanage.svg"style="width:25px;height:25px;">Employee Management</a></li>
    <!--<li><a href="editemp.php"><img src="assets/img/edit-icon.svg"style="width:25px;height:25px;">Edit Employee</a></li>  -->

    <li><a href="logout.php"><img src="assets/img/logout-icon.svg" alt="log-out-icon" style="width:25px;height:25px;">Logout</a></li>
</ul>
</nav>